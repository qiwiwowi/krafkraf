using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LoadBackGround : MonoBehaviour
{
    [Tooltip("����� ��ȯ�Ǵ� �ӵ��Դϴ�. �ִ밪�� 10�Դϴ�.")]
    [Range(0, 10)] [SerializeField] private float strength;

    [SerializeField] SpriteRenderer _spr;
    [SerializeField] Image _keyOutLine;

    public bool isAnim; //Ű���� �ִϸ��̼��� Ȱ��ȭ �Ǿ��°�?

    public static LoadBackGround instance;

    private void Start()
    {
        isAnim = false;
        StartCoroutine(FadeOut());
    }

    // Start is called before the first frame update
    void Awake()
    {
        if (instance != null) Destroy(gameObject);
        else
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
            _spr.enabled = true;
        }
    }  

    public IEnumerator FadeIn(bool SceneLoad = false, string sceneName = null) //ȭ�� ���̵���
    {
        Color _color = _spr.color;

        for (float i = 0; i < 1; i += Time.deltaTime * strength)
        {
            _color.a = i;
            _spr.color = _color;

            yield return  null;
        }

        if (SceneLoad && sceneName != null) SceneManager.LoadScene(sceneName);
    }

    public IEnumerator FadeOut(bool SceneLoad = false, string sceneName = null) //ȭ�� ���̵�ƿ�
    {
        Color _color = _spr.color;

        for (float i = 1; i > 0; i -= Time.deltaTime * strength)
        {
            _color.a = i;
            _spr.color = _color;


            yield return null;
        }

        if (SceneLoad && sceneName != null) SceneManager.LoadScene(sceneName);
    }

    public IEnumerator DualFade(int a = 1) //��� ��ȯ (-1�̸� ������, 1�̸� �ö�)
    {
        GameManager.instance.isAllMove = false; //ĳ���� ���� ����

        Color _color = _spr.color;

        StartCoroutine(ButtonCorutine());

        for (float i = 0; i < 1; i += Time.deltaTime * strength)
        {
            _color.a = i;
            _spr.color = _color;

            yield return null;
        }

        GameManager.instance.ChangeCurrentFloor(a);

        for (float i = 1; i > 0; i -= Time.deltaTime * strength)
        {
            _color.a = i;
            _spr.color = _color;

            yield return null;
        }
        GameManager.instance.isAllMove = true;
    }

    public IEnumerator ButtonCorutine() //Ű���� ä������ �ִϸ��̼�
    {
        _keyOutLine = GameObject.FindWithTag("KeyOutLine").GetComponent<Image>();

        for (float i = 0; i < 1; i += Time.deltaTime * strength)
        {
            _keyOutLine.fillAmount = i;

            yield return null;
        }
        _keyOutLine.fillAmount = 0;
    }
}
